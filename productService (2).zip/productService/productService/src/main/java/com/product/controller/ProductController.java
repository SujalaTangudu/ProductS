package com.product.controller;



import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.product.dto.ProductDTO;
import com.product.service.ProductService;

@RestController
@CrossOrigin
public class ProductController {

	Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	ProductService proser;
	
	@GetMapping(value = "/products",  produces = MediaType.APPLICATION_JSON_VALUE)
	public List<ProductDTO> getProducts(){
		logger.info("request for products");
		return proser.getProducts();
	}
	@GetMapping(value = "/product/{category}",  produces = MediaType.APPLICATION_JSON_VALUE)
	public List<ProductDTO> getProductsByCategory(@PathVariable String category){
		logger.info("request for products");
		return proser.getProductsByCategory(category);
	}
	@GetMapping(value = "/products/{productName}",  produces = MediaType.APPLICATION_JSON_VALUE)
	public List<ProductDTO> getProductsByProductName(@PathVariable String productName){
		logger.info("request for products");
		return proser.getProductsByProductName(productName);
	}
}
